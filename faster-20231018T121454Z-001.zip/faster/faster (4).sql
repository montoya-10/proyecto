-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 17-10-2023 a las 12:29:45
-- Versión del servidor: 8.0.31
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `faster`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargo`
--

DROP TABLE IF EXISTS `cargo`;
CREATE TABLE IF NOT EXISTS `cargo` (
  `id_cargo` int NOT NULL AUTO_INCREMENT,
  `cargo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_cargo`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `cargo`
--

INSERT INTO `cargo` (`id_cargo`, `cargo`) VALUES
(1, 'administrador web'),
(2, 'adninistrador tienda');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `idcategoria` int NOT NULL AUTO_INCREMENT,
  `categoria` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idcategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`idcategoria`, `categoria`) VALUES
(1, 'comida'),
(2, 'tecnologia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pqrs`
--

DROP TABLE IF EXISTS `pqrs`;
CREATE TABLE IF NOT EXISTS `pqrs` (
  `idpqrs` int NOT NULL AUTO_INCREMENT,
  `id` int NOT NULL,
  `names` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `asunto` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idpqrs`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pqrs`
--

INSERT INTO `pqrs` (`idpqrs`, `id`, `names`, `email`, `asunto`, `descripcion`) VALUES
(36, 12, 'felipe serna', 'felipeserna1999@gmail.com', 'sdfds', 'dfsfds');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `idproducto` int NOT NULL AUTO_INCREMENT,
  `idcategoria` int NOT NULL,
  `idreferencia` int NOT NULL,
  `idtienda` int NOT NULL,
  `nombreproducto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `precio` int NOT NULL,
  `costo` int NOT NULL,
  `utilidad` int NOT NULL,
  PRIMARY KEY (`idproducto`),
  KEY `fk_producto_categoria` (`idcategoria`),
  KEY `fk_producto_referencia` (`idreferencia`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`idproducto`, `idcategoria`, `idreferencia`, `idtienda`, `nombreproducto`, `descripcion`, `precio`, `costo`, `utilidad`) VALUES
(1, 2, 1, 2, 'samsung gañaxy s20 fe', 'dsfsdsf', 3900000, 3600000, 300000),
(2, 1, 2, 3, 'hamburgesa premium doble carne', 'sdfsdf', 35000, 28000, 7000),
(3, 1, 2, 3, 'hamburgesa sencilla ', 'dsfsdf', 15000, 12000, 3000),
(4, 1, 2, 3, 'hamburgesa a caballo', 'dsfsdf', 18000, 16000, 2000),
(5, 2, 1, 2, 'samsung galaxy a33 4g', 'dsfsdfds', 1599000, 1399000, 200000),
(6, 2, 1, 1, 'xiaomi note 12 s', 'dfsdfs', 870000, 770000, 100000),
(7, 2, 1, 1, 'tecno spark', 'dfsdfsd', 340000, 250000, 90000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recuperacion`
--

DROP TABLE IF EXISTS `recuperacion`;
CREATE TABLE IF NOT EXISTS `recuperacion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `random` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `referencia`
--

DROP TABLE IF EXISTS `referencia`;
CREATE TABLE IF NOT EXISTS `referencia` (
  `idreferencia` int NOT NULL AUTO_INCREMENT,
  `referencia` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idreferencia`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `referencia`
--

INSERT INTO `referencia` (`idreferencia`, `referencia`) VALUES
(1, 'celulares'),
(2, 'hamburgesas'),
(3, 'verduras');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiendas`
--

DROP TABLE IF EXISTS `tiendas`;
CREATE TABLE IF NOT EXISTS `tiendas` (
  `idtienda` int NOT NULL AUTO_INCREMENT,
  `tienda` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idtienda`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tiendas`
--

INSERT INTO `tiendas` (`idtienda`, `tienda`) VALUES
(1, 'mundo software'),
(2, 'repuestos sfs'),
(3, 'royerkingburger');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `idusuario` int NOT NULL AUTO_INCREMENT,
  `nombres` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imagen` longblob,
  `id_cargo` int DEFAULT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `nombres`, `usuario`, `email`, `password`, `numero`, `imagen`, `id_cargo`) VALUES
(21, 'felipe serna', 'repuestos', 'felipeserna1999@gmail.com', '633de4b0c14ca52ea2432a3c8a5c4c31', '3124267813', NULL, 0),
(22, 'felipe serna', 'felipeserna', 'felipeserna1999@gmail.com', '0a820f6cb284a5ec96c49ccdb0d2fd87', '3124267813', NULL, 1),
(23, 'sofia', 'sofia', 'felipeserna1999@gmail.com', '8acb123ab21a5ec371069e26e4c644a2', '3124267813', NULL, 0),
(24, 'felipe serna', 'felipe', 'felipeserna1999@gmail.com', '633de4b0c14ca52ea2432a3c8a5c4c31', '3124267813', NULL, 0),
(25, 'felipe serna', 'fdgfdg', 'felipeserna1999@gmail.com', '73c18c59a39b18382081ec00bb456d43', '3124267813', NULL, 0),
(26, 'felipe serna', 'vfvfv', 'felipeserna1999@gmail.com', 'c4055e3a20b6b3af3d10590ea446ef6c', 'fv', NULL, 1);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`idcategoria`) REFERENCES `categorias` (`idcategoria`),
  ADD CONSTRAINT `fk_producto_referencia` FOREIGN KEY (`idreferencia`) REFERENCES `referencia` (`idreferencia`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
