<?php
if(isset($_GET['enviar'])){
    $usuario = $_GET['usuario'];
    $password = $_GET['password'];
    $conexion = new mysqli('localhost', 'root', 'root', 'faster');

    $consulta = "SELECT * FROM usuarios WHERE usuario='$usuario'";
    $resultado = $conexion->query($consulta);
    if($resultado == true){
        if($resultado-> num_rows> 0){
            header('location: resultado.php?mensaje=excelente');
        }else{
            header('location: resultado.php?mensaje=fails');
        }
    }

}
?>