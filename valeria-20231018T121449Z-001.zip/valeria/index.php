<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            background-color: #f5f5f5;
        }

        form {
            margin: 0 auto;
            width: 500px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #000;
            color: #fff;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <form action="validacion.php" method="get">
        <div class="row">
            <input type="text" name="usuario" placeholder="usuario">
        </div>
        <div class="row">
        <input type="text" name="password" placeholder="password">
        </div>
        <div class="row">
        <input type="submit" name="enviar" value="send">
        </div>
    </form>
</body>
</html>