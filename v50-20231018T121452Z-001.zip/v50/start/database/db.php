<?php
//funcion solo para imagen 
function Getconnect()
{
  $connexion = new mysqli($host = 'localhost', $user = 'root', $password = 'root', $database = 'faster');
  return $connexion;
}

//clase para la connexion a la base de datos------------------------------------------------------------------
class crearconnexion
{
  public $host = 'localhost', $user = 'root', $password = 'root', $database = 'faster';
  public function Getconnectcass()
  {
    $connexion = new mysqli($this->host, $this->user, $this->password, $this->database);
    if ($connexion->connect_error) {
      die('no se pudo establecer la conecxion a la base de dtaos' . $connexion->connect_error);
    } else {
    }

    return $connexion;
  }
}
//-------------------------------------------------------------------------------------------------------------

//clase para agergar un usuario a la base de datos------------------------------------------------------------------
class nuevousuario extends crearconnexion
{
  public  $nombresr, $usuarior, $emailr, $passwordr, $vpasswordr, $numeror, $conect;

  public function __construct()
  {
    $this->conect = $this->Getconnectcass();
  }

  public function agergarusuario($nombres, $usuario, $email, $password, $vpassword, $numero)
  {
    $this->nombresr = $nombres;
    $this->usuarior = $usuario;
    $this->emailr = $email;
    $this->passwordr = $password;
    $this->vpasswordr = $vpassword;
    $this->numeror = $numero;

    $cosulta = "SELECT * FROM usuarios WHERE usuario='$this->usuarior'";
    $resultados = $this->conect->query($cosulta);
    if ($resultados == true) {
      if ($resultados->num_rows > 0) {
        echo "<script> window.location.href = 'registrarse?mensaje=el usuario ya existe'; </script>";
        $this->conect->close();
      } else {
        $insertar = "INSERT INTO usuarios(nombres, usuario, email, password, numero) VALUES('$this->nombresr', '$this->usuarior', '$this->emailr', '$this->passwordr', '$this->numeror')";
        $resultado = $this->conect->query($insertar);
        if ($resultado == true) {
          header('location: login?mensaje=se registraron los datos');
          $this->conect->close();
        } else {
          echo "<script> alert('ocurrio un problema en el proceso'); </script>";
          $this->conect->close();
        }
      }
    } else {
      echo "<script> alert('ocurrio un problema en el proceso'); </script>";
      $this->conect->close();
    }
  }
}
//------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------
//clase para ingresar al persfil login------------------------------------------------------------------------------
class login extends crearconnexion
{
  public $connectar, $usuarior, $passwordr;

  public function __construct()
  {
    $this->connectar = $this->Getconnectcass();
  }

  public function ingresarusuario($usuario, $password)
  {
    $this->usuarior = $this->connectar->real_escape_string($usuario);
    $this->passwordr = $this->connectar->real_escape_string(md5($password));
    $consulta = "SELECT * FROM usuarios WHERE usuario='$this->usuarior'";
    $resultado = $this->connectar->query($consulta);
    if ($resultado == true) {
      if ($resultado->num_rows > 0) {
        while ($fila = $resultado->fetch_assoc()) {
          $usuariook = $fila['usuario'];
          $paswordok = $fila['password'];
          $id = $fila['idusuario'];
          $id_cargo = $fila['id_cargo'];
        }
        $this->connectar->close();
        if ($this->usuarior === $usuariook && $this->passwordr === $paswordok) {
          $_SESSION['login'] = true;
          $_SESSION['id'] = $id;
          $_SESSION['usuario'] = $usuario;
          $_SESSION['cargo'] = $id_cargo;
          echo "<script> window.location.href = 'home'; </script>";
        } else {
          echo "<script> window.location.href = 'login?mensaje=datos incorrectos'; </script>";
        }
      } else {
        echo "<script> window.location.href = 'login?mensaje=el usuario no existe'; </script>";
      }
    } else {
      echo 'no';
    }
  }
}
//------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------
//clase para todo del perfil-------------------------------------------------------------------------
class perfil extends crearconnexion
{
  public $connexion;

  public function __construct()
  {
    $this->connexion = $this->Getconnectcass();
  }

  //funcion para añadir el boton administrar al usuario
  public function administrar()
  {
    $salida = " <div class='opciones-perfil'>" .
      "<a href='./administrar' target='_black'>" .
      "<button class='btn-perfils'> <img src='./img/administrar.png'>" .
      "<h1>administrar</h1>
        </button></a>" .
      "</div>";

    return $salida;
  }

  //funcion para entar al perfil de adminisrador
  function entraradmin($id_cargo, $id_usuario, $usuarioadmin, $passwordadmin)
  {
    $consulta = "SELECT * FROM usuarios WHERE id_cargo='$id_cargo' AND idusuario='$id_usuario' ";
    $resultado = $this->connexion->query($consulta);
    if ($resultado == true) {
      if ($resultado->num_rows > 0) {
        while ($fila = $resultado->fetch_assoc()) {
          $usuariook = $fila['usuario'];
          $passwordok = $fila['password'];
        }
        $passwordmd5 = $this->connexion->real_escape_string(md5($passwordadmin));
        $this->connexion->close();
        if ($usuarioadmin === $usuariook && $passwordmd5 === $passwordok) {
          echo "<script> window.location.href = 'go/admin'; </script>";
        } else {
          echo "<script> window.close(); </script>";
        }
      } else {
        echo "<script> window.close(); </script>";
      }
    } else {
      echo "<script> window.close(); </script>";
    }
  }
}
//------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------
//esta parte es para el container del home para los productos
//mostrar productos------------------
class showproducts extends crearconnexion
{
  public $connexion;
  public function __construct()
  {
    $this->connexion = $this->Getconnectcass();
  }
  //funcion para todos los productos-----------------------------
  function allproductos()
  {

    $salida = "";
    $contador = 0;
    $consulta = "SELECT * FROM productos";
    $resultado = $this->connexion->query($consulta);
    while ($fila = $resultado->fetch_array()) {
      $idproducto = $fila['idproducto'];
      $titulo = $fila['nombreproducto'];
      $descripcion = $fila['descripcion'];
      $precio = $fila['precio'];
      $precioformateado = number_format($precio, 0, '.', '.');
      $salida .= "<div class='tarjeta'>" .
        "<div class='titulo' data_titulo='$titulo'>" . $titulo . "</div>" .
        "<div class=''  style='display: '>" . "</div>" .
        "<div class='img'>" . "</div>" .
        "<div class='descripcion'>" . $descripcion . "</div>" .
        "<div class='precio'>" . "precio: " . $precioformateado . " pesos" . "</div>" .
        "<div class='clicker'>" .
        "<div class='btn_ver_producto'>" . "<button class='btn_ver_detalles_producto' data-idproducto='$idproducto'>Ver detalles</button>" . "</div>" .
        "<div class='btn_comprar_producto'>" . "<button>comprar</button>" . "</div>" .
        "</div>" .
        "</div>";
    }
    return $salida;
    $this->connexion->close();
  }

  //-fin de todos los productos-----------------------------
  //----------------------------------------------------------

  //fincion para los productos de tecnologia--------------------
  function tecnologyporducts()
  {
    $salida = '';
    $consulta = "SELECT * FROM productos WHERE idcategoria='2'";
    $resultado = $this->connexion->query($consulta);
    while ($fila = $resultado->fetch_array()) {
      $idproducto = $fila['idproducto'];
      $titulo = $fila['nombreproducto'];
      $descripcion = $fila['descripcion'];
      $precio = $fila['precio'];
      $precioformateado = number_format($precio, 0, '.', '.');
      $salida .= "<div class='tarjeta'>" .
        "<div class='titulo'>" . $titulo . "</div>" .
        "<div class='titulo'  style='display: none'>" . $idproducto . "</div>" .
        "<div class='img'>" . "</div>" .
        "<div class='descripcion'>" . $descripcion . "</div>" .
        "<div class='precio'>" . "precio: " . $precioformateado . " pesos" . "</div>" .
        "<div class='clicker'>" .
        "<div class='btn_ver_producto'>" . "<button class='btn_ver_detalles_producto'>Ver destalles</button>" . "</div>" .
        "<div class='btn_comprar_producto'>" . "<button>comprar</button>" . "</div>" .
        "</div>" .
        "</div>";
    }
    return $salida;
    $this->connexion->close();
  }
  //fin fincion para los productos de tecnologia------------------------
  //------------------------------------------------------------------------------------------------------------------

  //fincion para los productos de tecnologia--------------------
  function foodproducts()
  {
    $salida = '';
    $consulta = "SELECT * FROM productos WHERE idcategoria='1'";
    $resultado = $this->connexion->query($consulta);
    while ($fila = $resultado->fetch_array()) {
      $idproducto = $fila['idproducto'];
      $titulo = $fila['nombreproducto'];
      $descripcion = $fila['descripcion'];
      $precio = $fila['precio'];
      $precioformateado = number_format($precio, 0, '.', '.');
      $salida .= "<div class='tarjeta'>" .
        "<div class='titulo'>" . $titulo . "</div>" .
        "<div class='titulo' style='display: none'> " . $idproducto . "</div>" .
        "<div class='img'>" . "</div>" .
        "<div class='descripcion'>" . $descripcion . "</div>" .
        "<div class='precio'>" . "precio: " . $precioformateado . " pesos" . "</div>" .
        "<div class='clicker'>" .
        "<div class='btn_ver_producto'>" . "<button class='btn_ver_detalles_producto'>Ver destalles</button>" . "</div>" .
        "<div class='btn_comprar_producto'>" . "<button>comprar</button>" . "</div>" .
        "</div>" .
        "</div>";
    }
    return $salida;
    $this->connexion->close();
  }
  //fin fincion para los productos de tecnologia--------------------

  //funcion para mostrar los detalles completos del producto
  function mostrar_detalles($id_producto)
  {
    $salida = '';

    $consulta = "SELECT productos.nombreproducto, productos.descripcion, categorias.categoria, referencia.referencia, tiendas.tienda FROM productos";
    $consulta .= " INNER JOIN categorias ON productos.idcategoria = categorias.idcategoria";
    $consulta .= " INNER JOIN referencia ON productos.idreferencia = referencia.idreferencia";
    $consulta .= " INNER JOIN tiendas ON productos.idtienda = tiendas.idtienda";
    $consulta .= " WHERE idproducto = '$id_producto'";

    $resultado = $this->connexion->query($consulta);
    if ($resultado == true) {
      while ($fila = $resultado->fetch_assoc()) {
        $titulo_del_producto = $fila['nombreproducto'];
        $categoria_del_prducto = $fila['categoria'];
        $referencia_del_producto = $fila['referencia'];
        $descripcion_del_producto = $fila['descripcion'];
        $nombre_de_la_tienda = $fila['tienda'];
      }
      $this->connexion->close();
      $salida = "<div class='titulo_del_producto'>$titulo_del_producto</div>";
      $salida .= "<div class='imagen_del_producto'></div>";
      $salida .= "<div class='descripcion_del_producto'>Categoria: $categoria_del_prducto, Tipo de producto: $referencia_del_producto." . "<br>" . " Descripción: $descripcion_del_producto</div>";
      $salida .= "<div class='tienda_y_botones'>" .
        "<div class='tienda_del_producto'>Conoce nuestra tienda:" . "..." . "<button>Ir a: $nombre_de_la_tienda</button>" . "</div>" .
        "<div class='botones_del_producto'>" .
        "<button id='btn_regersar_a_los_producos'>Regresar a los productos</button>" . "<button id='btn_comprar'>Comprar producto</button>" .
        "</div>" .
        "</div>";
    } else {
      $salida = '<div>el resultado fallo</div>';
    }

    return $salida;
  }
  //------------------------------------------------------------------------------------------------------------------
}
