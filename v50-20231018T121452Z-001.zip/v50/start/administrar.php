<?php
session_start();
require('./database/db.php');
$id_usuario = $_SESSION['id'];
$id_cargo = $_SESSION['cargo'];
if (!isset($id_cargo)) {
    echo "<script> window.close(); </script>";
} else {
    if ($id_cargo == 0) {
        header('location: home');
    }else{
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrar</title>
    <link rel="stylesheet" href="./css/administrar.css">
    <script src="./javascript/administrar.js"></script>
</head>

<body>
    <!--inicio del nav-->
    <nav>
        <div class="columnas_de_este_nav">
            <h1>Modo Administrador</h1>
        </div>
        <div class="columnas_de_este_nav segunda_columna_de_este_nav">
            <button id="brn_cerrar">cerrar</button>
        </div>
    </nav>
    <!--din del nav-->
    <!-------------------------------------------------------------------------------->

    <!--inicio del section-->
    <section>
        <h1>Selecciona tu cargo</h1>
        <select name="" id="select_de_admin">
            <option value="">Administrador de la pagina</option>
            <option value="">Administrador de tienda</option>
        </select>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <div id="img">
                <img src="./img/loginimg.png" alt="">
            </div>
            <!--titulo-->
            <div class="row">
                <h1>Inicia sesion</h1>
            </div>
            <!--usuario-->
            <div class="row">
                <label for="">Usuario...</label>
                <input type="text" name="usuario">
            </div>
            <!--usuario-->
            <div class="row">
                <label for="">contraseña</label>
                <input type="password" name="password">
            </div>
            <!--boton-->
            <div class="row" id="row_del_btn">
                <input type="submit" name="enviar" id="btn_entrar_admin" value="entrar">
            </div>
        </form>
    </section>
    <!--fin del section-->
    <!-------------------------------------------------------------------------------->
    <!--script de php-->
    <?php
    if(isset($_POST['enviar'])){
        $usuario = $_POST['usuario'];
        $password = $_POST['password'];
        $entrar = new perfil;
        $entrar->entraradmin($id_cargo, $id_usuario, $usuario, $password);
    }
  
    ?>

</body>

</html>