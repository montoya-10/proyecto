<?php
session_start();
require('./database/db.php');
$usuario = $_SESSION['usuario'];
$id = $_SESSION['id'];
$id_cargo = $_SESSION['cargo'];
if (!isset($usuario)) {
    header('location: cerrar');
} else {
}
?>
<?php
$connexion = Getconnect();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi perfil</title>
    <link rel="stylesheet" href="./css/perfil.css">
    <link rel="stylesheet" href="./res/perfilr.css">
    <script src="./javascript/perfil.js"></script>
</head>

<body>
    <?php
    $cosulta = "SELECT * FROM usuarios WHERE idusuario='$id'";
    $resultado = $connexion->query($cosulta);
    $row = $resultado->fetch_array();
    $names = $row['nombres'];
    $user = $row['usuario'];
    $email = $row['email'];
    $numberphone = $row['numero'];
    $imagen = $row['imagen'];
    ?>
    <!--inicio del nav-->
    <div id="nav">
        <!--logo-->
        <div class="columnas">
            <div id="img">
                <img src="./img/logo.png" alt="logo">
            </div>
        </div>
        <!--boton cerrar seison-->
        <div class="columnas segunda">
            <div id="cerrar"><button id="btncerrarseison">cerrar sesion</button></div>
        </div>
    </div>
    <!--fin del nav-->
    <!--------------------------------------------->
    <!--inicio del container-->
    <div id="container">
        <!--pefil y foto-->
        <div class="column-container primera">
            <div id="foto-perfil">
                <input id="foto001" type="image" src="data:image/jpg;base64, <?php echo base64_encode($imagen) ?>">
            </div>
            <!--**********-->
            <!--boton de la foto del perfil-->
            <div id="boton-foto-perfil">
                <button id="btn-cambiar-foto">cambiar foto</button>
            </div>
            <!--**********-->
            <!--informacion del usuario-->
            <div id="informacion-del-usuario">
                <!--nombres-->
                <div class="row">
                    <label for="">nombres:</label> <input type="text" id="nombres" value="<?php echo $names ?>" disabled>
                </div>
                <!--usuario-->
                <div class="row">
                    <label for="">user:</label> <input type="text" id="" value="<?php echo $user ?>" disabled>
                </div>
                <!--email-->
                <div class="row">
                    <label for="">email:</label> <input type="text" id="" value="<?php echo $email ?>" disabled>
                </div>
                <!--numero-->
                <div class="row">
                    <label for="">numero:</label> <input type="text" id="nombres" value="<?php echo $numberphone ?>" disabled>
                </div>
            </div>

            <!--**********-->
            <!--boton regresar a la tienda-->
            <div id="row">
                <button id="btntienda">regresar a la tienda</button>
            </div>
        </div>

        <!--columna dos donde esta los ajuste del perfil-->
        <div class="column-container segunda-perfil">
            <!--austes del perdil-->
            <div class="opciones-perfil">
                <button class="btn-perfils"> <img src="./img/ajustes.png">
                    <h1>ajustes de usuario</h1>
                </button>
            </div>
            <!---->
            <div class="opciones-perfil">
                <button class="btn-perfils"> <img src="./img/metodosdepago.png">
                    <h1>metodos de pago</h1>
                </button>
            </div>
            <!---->
            <div class="opciones-perfil">
                <button class="btn-perfils"> <img src="./img/historial-de-transacciones.png">
                    <h1>hostorial de compras</h1>
                </button>
            </div>
            <!---->
            <div class="opciones-perfil">
                <button class="btn-perfils"> <img src="./img/eliminar-usuario.png">
                    <h1>eliminar usuario</h1>
                </button>
            </div>
            <!---->
            <div class="opciones-perfil">
                <button class="btn-perfils"> <img src="./img/favorito.png">
                    <h1>productos favoritos</h1>
                </button>
            </div>
            <!---->
            <div class="opciones-perfil">
                <a href="./soporte" target="_black">
                    <button class="btn-perfils"> <img src="./img/apoyo-tecnico.png">
                        <h1>soporte al cliente</h1>
                    </button></a>
            </div>
            <!---->
            <?php
            if (isset($id_cargo)) {
                if (!$id_cargo == 0) {
                    $opciones_perfil = new perfil;
                    echo $opciones_perfil->administrar();
                }
            }
            ?>
        </div>
    </div>
    <!--fin del container-->
    <!--------------------------------------------->
    <!--consulta a la base de datos de la prsona-->
</body>

</html>