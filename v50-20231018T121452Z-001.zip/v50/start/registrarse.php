<?php
error_reporting(0);
session_start();
require('./database/db.php');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link rel="stylesheet" href="css/registrarse.css">
    <link rel="stylesheet" href="./res/registraser.css">
    <script src="./javascript/registrase.js"></script>
</head>

<body>
    <!--inicio del nav-->
    <div id="nav">
        <!--logo-->
        <div class="nav-columnas">
            <div id="nav-img"> <img src="./img/logo.png" alt="logo"> </div>
        </div>
        <!--menu-->
        <div class="nav-columnas segunda">
            <ul>
                <li><a class="a" href="">soporte</a></li>
                <li><a class="a" href="">contacto</a></li>
                <li><a class="a" href="">acerca de:</a></li>
                <li><button id="btnlogin">🏠inicio</button></li>
            </ul>
        </div>
    </div>
    <!--fin del nav-->
    <!------------------------------------------------------>
    <!--nav para novil-->
    <div id="nav-movil">
        <!--logo-->
        <div class="columnas-menu-movil">
            <div id="nav-img"> <img src="./img/logo.png" alt="logo"> </div>
        </div>
        <!--boton menu del movil-->
        <div class="columnas-menu-movil boton001">
            <div id="boton-menu-movil">
                <button type="button" id="btn-menu-movil">☰</button>
            </div>
        </div>
    </div>
    <!--fin del nav para celulares-->
    <!------------------------------------------------------>
    <!--menu del nav para movil-->
    <div id="menu-movil">
        <ul>
            <li><a class="a" href="">soporte</a></li>
            <li><a class="a" href="">contacto</a></li>
            <li><a class="a" href="">acerca de:</a></li>
            <li><button id="btnloginmovil">🏠inicio</button></li>
        </ul>
    </div>
    <!--fin dl menu del nav para movil-->
    <!------------------------------------------------------>
    <!--incio del container-->
    <div id="container">
        <br>
        <h1>REGISTRARSE</h1>
        <br>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
             <!--Nombres-->
             <div class="row">
                <label for="">Nombre</label>
                <input type="text" name="nombres" id="" placeholder="" required>
            </div>
            <!--Usuario-->
            <div class="row">
                <label for="">ususario</label>
                <input type="text" name="usuario" id="" placeholder="" required>
            </div>
            <!--Email-->
            <div class="row">
                <label for="">email</label>
                <input type="email" name="email" id="" placeholder="" required>
            </div>
            <!--Contraseña-->
            <div class="row">
                <label for="">contraseña</label>
                <div class="rowpass">
                <input type="password" name="password" class="password" id="password" placeholder="" required><input class="ojitos" id="ojo" type="button" value="👀">
                </div>
            </div>
            <!--verificar Contraseña-->
            <div class="row">
                <label for="">verificar contraseña</label>
                <input type="password" name="vpassword" class="password" id="" placeholder="" required>
            </div>
            <!--Telefono-->
            <div class="row">
                <label for="">telefono</label>
                <input type="text" name="telefono" id="" placeholder="" required>
            </div>
            <div class="ro">
                <!--espacio necesario-->
            </div>
            <div class="row">
                <input id="btnenviardatos" name="enviar" type="submit" value="registrarse">
            </div>
        </form>
        <?php $mensaje = $_GET['mensaje'];
        echo "<h1>" . $mensaje . "</h1>";
        echo "<h1>" . $alerta . "</h1>";
        ?>
    </div>
    <!--script de php-->
    <?php
    //llamado a la función de la conexión de datos
    //insersion de datos
    if (isset($_POST['enviar'])) {
        $nombres = $_POST['nombres'];
        $usuario = $_POST['usuario'];
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        $vpassword = md5($_POST['vpassword']);
        $numero = $_POST['telefono'];
        /*echo "<script> alert('si existe'); </script>";*/
        $nuevo = new nuevousuario;
        $nuevo->agergarusuario($nombres, $usuario, $email, $password, $vpassword, $numero);
    }


    ?>
    <!--fin del container-->
    <!------------------------------------------------------>
</body>

</html>