<?php
session_start();
include('./database/db.php');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperacion de clave</title>
    <link rel="stylesheet" href="./css/recuperacion.css">
    <link rel="stylesheet" href="./cssresposive/recuperacionr.css">
</head>

<body>
    <!--inicio del container-->
    <div id="container">
        <!--titulo-->
        <div id="titulo">
            <h1>Sistema de ingreso a la validación de usuario</h1>
        </div>
        <!--descripción-->
        <div id="descripcion">
            <h2>Revisa tu correo electronico</h2>
            <p>Hemos enviado un mensaje a tu correo electroníco donde vas a encontrar la llave de acceso,
                utilizala para poder ingresar y poder cambiar tu clave de usuario, una vez la tengas
                ingresala aqui nunto a tu usuario
            </p>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                <div id="acceso">
                     <!--para la usuario-->
                     <div class="row">
                        <input type="text" name="usuario" placeholder="Usuario" required>
                    </div>
                    <!--para la llave-->
                    <div class="row">
                        <input type="text" name="llave" placeholder="Llave de acceso" required>
                    </div>
                    <!--boton de enviar-->
                    <div class="row">
                        <input type="submit" name="enviar" value="Entrar">
                    </div>
                </div>
            </form>

        </div>
    </div>
    <!--fin del container-->
    <!--------------------------------------------->
    <!--codigo php-->
    <?php
    $coon = Getconnect();
    if (isset($_POST['enviar'])) {
        $llave = $_POST['llave'];
        $usuario = $_POST['usuario'];
        $query = "SELECT * FROM recuperacion WHERE random='$llave'";
        $resultado = $coon->query($query);
        while ($row = $resultado->fetch_assoc()) {
            $llaveok = $row['random'];
            $id = $row['id'];
        }
        if($llave === $llaveok){
         $cosulta = "SELECT * FROM usuarios WHERE usuario='$usuario'";
         $resut = $coon->query($cosulta);
         while($fila = $resut->fetch_assoc()){
            $userok = $fila['usuario'];
            $iduser = $fila['idusuario'];
         }
      
         if($usuario === $userok){
            $_SESSION['usercambio'] = $usuario;
            $_SESSION['id'] = $iduser;
            header('location: cambioclave');
            $borrar = "DELETE FROM recuperacion WHERE id='$id'";
            $listo = $coon->query($borrar);
            $resultado->close();
            $resut->close();
            $listo->close();
            $coon->close();
            exit();
         }
        }
    }
    ?>
</body>

</html>