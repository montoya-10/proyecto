<?php
session_start();
session_unset();
session_destroy();
$mensaje = $_GET['mensaje'];
header('location: login?mensaje='.$mensaje);
?>