document.addEventListener("DOMContentLoaded", function () {
    let btnlogin = document.getElementById('btnlogin');
    //boton de inicio
    btnlogin.addEventListener('mouseover', () => {
        btnlogin.style.fontSize = '70%';
        btnlogin.style.background = 'white';
        btnlogin.style.color = 'black';
    });
    btnlogin.addEventListener('mouseout', () => {
        btnlogin.style.fontSize = '';
        btnlogin.style.background = '';
        btnlogin.style.color = '';
    });
    btnlogin.addEventListener('click', () => {
        window.location.href = './login';
    });
    //fin del boton de inicio
    //-------------------------------------------------------------------------------------
    //boton para el movil
    let btnmenumovilhome = document.getElementById('btnloginmovil');
    btnmenumovilhome.addEventListener('mouseover', () => {
        btnmenumovilhome.style.fontSize = '70%';
        btnmenumovilhome.style.background = 'white';
        btnmenumovilhome.style.color = 'black';
    });
    btnmenumovilhome.addEventListener('mouseout', () => {
        btnmenumovilhome.style.fontSize = '';
        btnmenumovilhome.style.background = '';
        btnmenumovilhome.style.color = '';
    });
    btnmenumovilhome.addEventListener('click', () => {
        window.location.href = './login';
    });
    //fin del boton para el movil
    //los a del nav
    let a = document.querySelectorAll('.a');
    a.forEach(Element => {
        Element.addEventListener('mouseover', () => {
            Element.style.textShadow = '2px 2px 4px white';
            Element.style.color = '#81B8EF';
        });
        Element.addEventListener('mouseout', () => {
            Element.style.textShadow = '';
            Element.style.color = '';
        });
    });
    //fin de los a del nav
    //-------------------------------------------------------------------------------------
    //boton para desplegar el menu del movil
    let btnmenumovil = document.getElementById('btn-menu-movil');
    btnmenumovil.addEventListener('click', () => {
        let menuparamovil = document.getElementById('menu-movil');
        if (btnmenumovil.type === 'button') {
            menuparamovil.style.display = 'flex';
            btnmenumovil.type = 'submit';
        } else {
            menuparamovil.style.display = 'none';
            btnmenumovil.type = 'button';
        }
    });
    //fin del boton para desplegar el menu del movil
    //-------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------
    //esta es la barra de busqueda de los dos nav---------------------------------------------
    let barras_del_nav_juntas = document.querySelectorAll('.barras_del_nav_juntas');
    barras_del_nav_juntas.forEach(Element => {
        Element.addEventListener('mouseover', () => {
            Element.style.border = '2px solid #0000ff66';
        });
        Element.addEventListener('mouseout', () => {
            Element.style.border = '1px outset #0000ff66';
        });
    });
    //para cambiar el estilo del boton de la barra de busqueda boton-------------------------
    let barra_busqueda_imput = document.querySelectorAll('.barra-busqueda-imput');
    barra_busqueda_imput.forEach(Element_barra_busqueda_imput => {
        Element_barra_busqueda_imput.addEventListener('input', () => {
            let valor = Element_barra_busqueda_imput.value;
            if (valor.length >= 1) {
                document.querySelectorAll('.btn-search').forEach(Element_btn_search => {
                    Element_btn_search.textContent = 'X';
                });
            } else {
                document.querySelectorAll('.btn-search').forEach(Element_btn_search => {
                    Element_btn_search.textContent = '🔍';
                });
            }
        });
    });
    //boton de la barra de bsuueda para borrar texto del input-----------------------------
    let btn_search_delete = document.querySelectorAll('.btn-search');
    btn_search_delete.forEach(Elemente => {
        Elemente.addEventListener('mouseover', () => {
            Elemente.style.cursor = 'pointer';
        });
        Elemente.addEventListener('click', () => {
            document.querySelectorAll('.barra-busqueda-imput').forEach(Elemente_barra => {
                Elemente_barra.value = '';
                Elemente.textContent = '🔍';

            });
        });
    });
    //----------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------
    //etsa parte es para el perfil del navin-------------------------------------------------
    let menu_del_perfil_navin = document.getElementById('select-del-menu');
    menu_del_perfil_navin.addEventListener('mouseover',()=>{
        menu_del_perfil_navin.style.cursor = 'pointer';
        menu_del_perfil_navin.click();
    });


    menu_del_perfil_navin.addEventListener('change', () => {
        let valor_menu_del_perfil_navin = menu_del_perfil_navin.value;
        if (valor_menu_del_perfil_navin == 'Perfil') {
            window.location.href = 'perfil';
        }else if (valor_menu_del_perfil_navin == 'cerrarsesion') {
            let window_confirm_cerrarsesion = confirm('¿seguro quieres cerrar sesion?');
            if (window_confirm_cerrarsesion) {
                window.location.href = 'cerrar';
            } else {
                menu_del_perfil_navin.value = '';
            }
        }
    });
    //----------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------
    //qui empieza el secttion y todo lo que coniene----------------------------------------

    //productos----------------------------------------------------------------------------
    let allproducts = document.getElementById('allproducts');
    let tecnologyproducts = document.getElementById('tecnologyproducts');
    let foodporducts = document.getElementById('foodporducts');

    //categorias---------------------------------------------------------------------------
    let select = document.getElementById('select');
    select.addEventListener('change', () => {
        if (select.value === 'todaslascategorias') {
            allproducts.style.display = 'flex';
            tecnologyproducts.style.display = 'none';
            foodporducts.style.display = 'none';

        } else if (select.value === 'comida') {
            allproducts.style.display = 'none';
            tecnologyproducts.style.display = 'none';
            foodporducts.style.display = 'flex';

        } else if (select.value === 'tecnologia') {
            allproducts.style.display = 'none';
            tecnologyproducts.style.display = 'flex';
            foodporducts.style.display = 'none';
        }
    });
    // fin categorias-----------------------------------------------------------------------

    // boton detalles del producto----------------------------------------------------------
    let btn_ver_detalles_producto = document.querySelectorAll('.btn_ver_detalles_producto');
    btn_ver_detalles_producto.forEach(Element => {
        Element.addEventListener('mouseover', () => {
            Element.style.cursor = 'pointer';
        });
        Element.addEventListener('click', () => {
            let idproducto = Element.getAttribute('data-idproducto');
            window.open('destalles_del_producto?id_producto=' + idproducto);
        });

    });
    //fin detalles del producto------------------------------------------------------------


    //fin del section y todo lo que contiene--------------------------------------------------
    //----------------------------------------------------------------------------------------
});
