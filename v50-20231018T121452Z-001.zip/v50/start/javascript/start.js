document.addEventListener('DOMContentLoaded',()=>{
    setTimeout(() => {
        window.location.href ='home';
    }, 2000);
});