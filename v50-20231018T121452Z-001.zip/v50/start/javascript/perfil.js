'use strict';
//documento cargado completo
document.addEventListener('DOMContentLoaded', () => {
    //boton cerrar sesion
    let btncerrarseison = document.getElementById('btncerrarseison');
    btncerrarseison.addEventListener('mouseover', () => {
        btncerrarseison.style.background = 'white';
        btncerrarseison.style.color = 'black';
        btncerrarseison.style.fontSize = '50%';
    });
    btncerrarseison.addEventListener('mouseout', () => {
        btncerrarseison.style.background = '';
        btncerrarseison.style.color = '';
        btncerrarseison.style.fontSize = '';
    });
    btncerrarseison.addEventListener('click', () => {
        window.location.href = 'cerrar.php?mensaje= se cerro sesion';
    });
    //fin del boton cerrar seion
    //******************************************* */
    //boton cambiar foto de perfil

    let btncambiarfoto = document.getElementById('btn-cambiar-foto');
    btncambiarfoto.addEventListener('mouseover', function(){
        btncambiarfoto.style.cursor = 'pointer';
        btncambiarfoto.style.background = 'black';
        btncambiarfoto.style.color = 'white';
        btncambiarfoto.style.fontSize = '50%';
        });
        btncambiarfoto.addEventListener('mouseout', function(){
            btncambiarfoto.style.cursor = '';
            btncambiarfoto.style.background = '';
            btncambiarfoto.style.color = '';
            btncambiarfoto.style.fontSize = '';
            });
            btncambiarfoto.addEventListener('click', ()=>{
                window.location.href = 'settings/subirfoto';
            });


    //fin del boton cambiar foto de perfil
    //*********************************************/
    //boton regresar a la tienda
    let btntienda = document.getElementById('btntienda');
    btntienda.addEventListener('mouseover', () => {
        btntienda.style.background = 'black';
        btntienda.style.color = 'white';
        btntienda.style.cursor = 'pointer';
        btntienda.style.borderRadius = '5px';
        btntienda.style.fontSize = '50%';
    });
    btntienda.addEventListener('mouseout', () => {
        btntienda.style.background = '';
        btntienda.style.color = '';
        btntienda.style.cursor = '';
        btntienda.style.borderRadius = '';
        btntienda.style.fontSize = '';
    });
    btntienda.addEventListener('click', () => {
        window.location.href = 'home';
    });
    //fin del boton regresar a la tienda
    //*********************************************/
    //botones el perfil usuario
    let btnperfilclass = document.querySelectorAll('.btn-perfils');
    btnperfilclass.forEach(Event =>{
        Event.addEventListener('mouseover', ()=>{
            Event.style.boxShadow = '0px 0px 30px blue';
        });
        Event.addEventListener('mouseout', ()=>{
            Event.style.boxShadow = '';
        });
    })
});