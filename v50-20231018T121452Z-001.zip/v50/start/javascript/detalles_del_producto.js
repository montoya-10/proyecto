document.addEventListener('DOMContentLoaded', () => {
    //--------------------------------------------------------------------------------
    //boton cerrar-------------------------------------------------------------------
    const btn_cerrar = document.getElementById('btn_cerrar');
    btn_cerrar.addEventListener('mouseover', () => {
        btn_cerrar.style.cursor = 'pointer';
    });
    btn_cerrar.addEventListener('click', () => {
        window.close();
    });
    //--------------------------------------------------------------------------------

    //--------------------------------------------------------------------------------
    //btn regresar a los productos----------------------------------------------------
    const btn_regersar_a_los_producos = document.getElementById('btn_regersar_a_los_producos');
    btn_regersar_a_los_producos.addEventListener('mouseover', () => {
        btn_regersar_a_los_producos.style.cursor = 'pointer';
    });
    btn_regersar_a_los_producos.addEventListener('click', () => {
        window.close();
    });
    //--------------------------------------------------------------------------------

    //--------------------------------------------------------------------------------
    //btn comprar---------------------------------------------------------------------
    const btn_comprar = document.getElementById('btn_comprar');
    btn_comprar.addEventListener('mouseover', ()=>{
        btn_comprar.style.cursor = 'pointer';
    });
    //--------------------------------------------------------------------------------
});