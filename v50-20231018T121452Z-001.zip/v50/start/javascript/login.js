//cargar todo el documento
document.addEventListener('DOMContentLoaded', () => {
    let btnlogin = document.getElementById('btnlogin');
    //boton de inicio
    btnlogin.addEventListener('mouseover', () => {
        btnlogin.style.fontSize = '70%';
        btnlogin.style.background = 'white';
        btnlogin.style.color = 'black';
    });
    btnlogin.addEventListener('mouseout', () => {
        btnlogin.style.fontSize = '';
        btnlogin.style.background = '';
        btnlogin.style.color = '';
    });
    btnlogin.addEventListener('click', () => {
        window.location.href = 'home';
    });
    //fin del boton de inicio
    //-------------------------------------------------------------------------------------
    //boton para el movil
    let btnmenumovilhome = document.getElementById('btnloginmovil');
    btnmenumovilhome.addEventListener('mouseover', () => {
        btnmenumovilhome.style.fontSize = '70%';
        btnmenumovilhome.style.background = 'white';
        btnmenumovilhome.style.color = 'black';
    });
    btnmenumovilhome.addEventListener('mouseout', () => {
        btnmenumovilhome.style.fontSize = '';
        btnmenumovilhome.style.background = '';
        btnmenumovilhome.style.color = '';
    });
    btnmenumovilhome.addEventListener('click', () => {
        window.location.href = 'home';
    });
    //fin del boton para el movil
    //los a del nav
    let a = document.querySelectorAll('.a');
    a.forEach(Element => {
        Element.addEventListener('mouseover', () => {
            Element.style.textShadow = '2px 2px 4px white';
            Element.style.color = '#81B8EF';
        });
        Element.addEventListener('mouseout', () => {
            Element.style.textShadow = '';
            Element.style.color = '';
        });
    });
    //fin de los a del nav
    //-------------------------------------------------------------------------------------
    //mostrar contraseña
    let ojito = document.getElementById('ojito');
    ojito.addEventListener('click', ()=>{
        let password = document.getElementById('password');
        if(password.type === 'password'){
            password.type = 'text';
            ojito.value = '🫣';
        }else{
            password.type = 'password';
            ojito.value = '👀';
        }
    });
    //boton para entar al pefil
    let btnenviardatos = document.getElementById('btnenviardatos');
    btnenviardatos.addEventListener('click', ()=>{
        btnenviardatos.type = 'submit';
    });
    //boton para desplegar el menu del movil
    let btnmenumovil = document.getElementById('btn-menu-movil');
    btnmenumovil.addEventListener('click', ()=>{
        let menuparamovil = document.getElementById('menu-movil');
        if(btnmenumovil.type === 'button'){
           menuparamovil.style.display = 'flex';
           btnmenumovil.type = 'submit';
        }else{
            menuparamovil.style.display = 'none';
            btnmenumovil.type = 'button';
        }
    });
});