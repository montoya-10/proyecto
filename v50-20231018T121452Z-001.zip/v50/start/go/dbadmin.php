<?php
require('../database/db.php');
?>
<?php
class admin extends crearconnexion
{
    public $connexion;
    public function __construct()
    {
        $this->connexion = $this->Getconnectcass();
    }

    function verificar()
    {
        if($this->connexion){
            echo 'si';
        }else{
            echo 'no';
        }
    }
}

?>