<?php
session_start();
require('./dbadmin.php');
$id_usuario = $_SESSION['id'];
$id_cargo = $_SESSION['cargo'];
if (!isset($id_usuario) && !isset($id_cargo)) {
    echo "<script> window.location.href = '../home'; </script>";
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>

<body>
    
</body>

</html>