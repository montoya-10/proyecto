<?php
require('./database/db.php');
error_reporting(0);
session_start();
$usuario = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="./css/home.css">
    <script src="./javascript/home.js"></script>
</head>

<body>
    <?php
    if (isset($usuario)) {
        include('./php/navin.php');
    } else {
        include('./php/nav.php');
    }
    ?>

    <!--espaio publicitario-->
    <div id="espacio_publicitario">

    </div>
    <!--fin del espaion publicitario-->
    <!----------------------------------------------------------------------->

    <!--inicio del section-->
    <section>
        <!--categorias-->
        <div class="columnasas primerass">
            <h1>Busqueda mas especifica</h1>
            <ul>
                <!--celulares-->
                <li>
                    <div class="circulo_check"><input type="checkbox" class="input_check" id="check_celulares"></div><label for="">Celulares</label>
                </li>
                <!--hamburgesas-->
                <li>
                    <div class="circulo_check"><input type="checkbox" class="input_check" id="check_celulares"></div><label for="">hamburgesas</label>
                </li>
                <!--audifionos-->
                <li>
                    <div class="circulo_check"><input type="checkbox" class="input_check" id="check_celulares"></div><label for="">audifonos</label>
                </li>
                   <!--audifionos-->
                   <li>
                    <div class="circulo_check"><input type="checkbox" class="input_check" id="check_celulares"></div><label for="">cargadores</label>
                </li>
            </ul>
        </div>
        <!--productos-->
        <div class="columnasas segundass">
            <!--todos los productos-->
            <div class="allpp" id="allproducts">
                <?php
                $tarjeta = new showproducts;
                echo $tarjeta->allproductos();
                ?>
            </div>
            <!--productos de tecnologia-->
            <div class="allpp" id="tecnologyproducts" style="display: none;">
                <?php
                $tarjeta = new showproducts;
                echo $tarjeta->tecnologyporducts();
                ?>
            </div>
            <!--productos de tecnologia-->
            <div class="allpp" id="foodporducts" style="display: none;">
                <?php
                $tarjeta = new showproducts;
                echo $tarjeta->foodproducts();
                ?>
            </div>

        </div>

    </section>
    <!--fin del section-->
    <!----------------------------------------------------------------------->

    <!--inicio del footer-->
    <footer>
        <!---->
        <h1>Todos los derechos son reservados... <span>@Faster.com</span></h1>
    </footer>
    <!--fin del footer-->
    <!----------------------------------------------------------------------->

</body>

</html>