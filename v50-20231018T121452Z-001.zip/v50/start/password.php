<?php
error_reporting(0);
include('./database/db.php');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <link rel="stylesheet" href="./css/password.css">
    <link rel="stylesheet" href="./resposive/passwordr.css">
</head>

<body>
    <!--inicio del contenedor-->
    <div id="container">
        <div id="cuadro">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                <!--primera fila-->
                <div id="firstrow">
                    <br>
                    <h1>Recupuperación de contraseña</h1>
                </div>
                <!--formulario-->

                <!--segunda fila para el email-->
                <div class="row">
                    <div id="email">
                        <label for="email">Email:</label>
                        <input type="" name="email" id="email" placeholder="Escribe el email que hallas registrado.">
                    </div>
                </div>
                <!--tercera fila boton enviar-->
                <div class="row">
                    <input type="submit" name="enviar" id="enviarbtnc" value="Enviar">
                </div>
            </form>
            <?php $done = $_GET['mensaje'];
            echo $done;
            ?>

        </div>
    </div>
    <!--fin del contenedor-->
    <!-------------------------------------------->
    <!--codigo de php-->
    <?php
        $connexio = Getconnect();
    if (isset($_POST['enviar'])) {
        $llave = '';
        for($i=0; $i <4; $i++){
            $llave = mt_rand(0, 9);
            $llavepass.= $llave;
        } 
        $email = $_POST['email'];
        $dirrecion = 'https://repuestossfsbymundosoftware.com/main12/home/recuperacion';
        $asunto = 'Recuperacion de contraseña';
        $header = "from: Soporte gvc" . "\r\n";
        $header .= "Reply-To: noreply@example.com" . "\r\n";
        $header .= "su llave de acceso es: ".$llavepass;
        $mail = @mail($email, $asunto, $header);
        $envio = "INSERT INTO recuperacion (email, random) VALUES('$email','$llavepass')";
        $resultado = $coon->query($envio);
        header('location: ../recuperacion?mensaje=revisa tu correo electronico');
    }
    ?>
</body>

</html>