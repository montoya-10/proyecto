<?php
require('./database/db.php');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del poducto</title>
    <link rel="stylesheet" href="./css/detalles_del_producto.css">
    <script src="./javascript/detalles_del_producto.js"></script>
</head>

<body>
    <!--inicio del nav-->
    <nav>
        <div class="columnas_de_detalles_de_producto primera_columna_de_detalles"><h1>Detalles del porducto</h1></div>
        <div class="columnas_de_detalles_de_producto segunda_columna_de_detalles"><button id="btn_cerrar">Cerrar</button></div>
     
    </nav>
    <!--fin del nav-->
    <!--------------------------------------------------->

    <!--inicio del section-->
    <section>
        <?php
        $id_producto_por_get = $_GET['id_producto'];
        $info = new showproducts;
        echo $info->mostrar_detalles($id_producto_por_get);
        ?>
    </section>
    <!--fin del section-->
    <!--------------------------------------------------->
</body>

</html>