<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cargando...</title>
    <link rel="stylesheet" href="css/start.css">
    <script src="./javascript/start.js"></script>
</head>

<body>
    <!--inicio del section-->
    <section>
        <!--tuerca-->
        <div id="tuerca">
            <img src="./img/tuerca.png">
        </div>
        <!--titulo-->
        <div id="titulo">
            <h1>Faster.com</h1>
            <h2>Cargando.....</h2>
        </div>
    </section>
    <!--fin del section-->
    <!----------------------------------------------------------->
</body>

</html>