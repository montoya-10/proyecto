 <!--todo ste codigo no sirve pero toca dejarlo hay-->
<div id="select-del-menu" style="display: none;"></div>
<!--fin de todo ste codigo no sirve pero toca dejarlo hay-->
<!----------------------------------------------------------------------------------->
 <!--inicio del nav-->
 <div id="nav">
     <!--logo-->
     <div class="nav-columnas">
         <a href="../dir.php">
             <div id="nav-img"> <img src="./img/logo.png" alt="logo"> </div>
         </a>
     </div>
     <!--menu-->
     <div class="nav-columnas segunda">
         <ul>
             <li><a class="a" target="_black" href="soporte">soporte</a></li>
             <li><a class="a" target="_black" href="contacto">contacto</a></li>
             <li><a class="a" href="">acerca de:</a></li>
             <li><button id="btnlogin">🧍Ingresar</button></li>
         </ul>
     </div>
 </div>
 <!--fin del nav-->
 <!------------------------------------------------------>
 <!--nav para novil-->
 <div id="nav-movil">
     <!--logo-->
     <div class="columnas-menu-movil">
         <a href="../dir.php">
             <div id="nav-img"> <img src="./img/logo.png" alt="logo"> </div>
         </a>
     </div>
     <!--boton menu del movil-->
     <div class="columnas-menu-movil boton001">
         <div id="boton-menu-movil">
             <button type="button" id="btn-menu-movil">☰</button>
         </div>
     </div>
 </div>
 <!--fin del nav para celulares-->
 <!------------------------------------------------------>
 <!--menu del nav para movil-->
 <div id="menu-movil">
     <ul>
         <li><a class="a" href="">soporte</a></li>
         <li><a class="a" href="">contacto</a></li>
         <li><a class="a" href="">acerca de:</a></li>
         <li><button id="btnloginmovil">🧍ingresar</button></li>
     </ul>
 </div>
 <!--fin dl menu del nav para movil-->
 <!------------------------------------------------------>

 <!--header-->
 <div id="header">
     <!--logo y barra de busqueda-->
     <div class="columnas-del-nav primera-columna-del-nav">
         <!--logo-->
         <div id="logo-del-nav">
             <img src="./img/logo.png">
         </div>
         <!--barra de usqueda-->
         <div id="barra-de-busqueda-del-nav" class="barras_del_nav_juntas">
             <input type="text" class="barra-busqueda-imput" placeholder="Buscar" value=""> <button class="btn-search">🔍</button>
         </div>
     </div>
     <!--categorias, iniciar session y canasta-->
     <div class="columnas-del-nav seguda-columna-del-nav">
         <!--categorias-->
         <div id="categorias-del-nav">
             <select class="select-del-nav" name="" id="select">
                 <option value="todaslascategorias">todas las categorias</option>
                 <option value="comida">comida</option>
                 <option value="tecnologia">tecnologia</option>
             </select>
         </div>
         <!--ingresar usuario-->
         <div id="ingresar-usuario-del-nav">
             <button id="btn-ingresar-usuario-del-nav">🧍Ingresar</button>
         </div>
         <!--canasta-->
         <div id="canasta">
             <button id="button-canasta"><img src="./img/canasta.png" alt=""></button>
         </div>
     </div>
 </div>

 <!--fin del header-->
 <!------------------------------------------------------>