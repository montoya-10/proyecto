<!--todo ste codigo no sirve pero toca dejarlo hay-->
<button id="btnlogin" style="display: none;"></button>
<button type="button" id="btn-menu-movil" style="display: none;">☰</button>
<button id="btnloginmovil" style="display: none;">🧍ingresar</button>
<!--fin de todo ste codigo no sirve pero toca dejarlo hay-->
<!----------------------------------------------------------------------------------->

<!--inicio del top-->
<div id="top">
    <!--logo-->
    <div class="cajastop">
        <div id="logo"><a href="./gohome"><img src="./img/logo.png"></a></div>
    </div>
    <!--soporte-->
    <div class="cajastop second">
        <ul>
            <li><a href="./perfil">perfil</a></li>
            <li><a href="">inicio</a></li>
            <li><a href="#nav">volver arriba</a></li>
        </ul>
    </div>
</div>
<!--fin del top-->
<!-------------------------------------------------->
<!--inicio del nav-->
<div id="navin">
    <!--esta primera columna abarca el logo y la barra de busqueda-->
    <div class="columnasprincipales">
        <!--logo-->
        <div id="logocolumna">
            <img src="./img/logo.png" alt="">
        </div>
        <!--barra de busqueda-->
        <div id="barra-de-busqueda" class="barras_del_nav_juntas">
            <input type="text" class="barra-busqueda-imput" placeholder="Buscar"> <button class="btn-search">🔍</button>
        </div>
    </div>
    <!--esta segunda columna es para las categorias, perfil y la canasta-->
    <div class="columnasprincipales segundacolpr">
        <!--este es para las categorias-->
        <div id="categorias">
            <select name="" id="select">
                <option value="todaslascategorias" selected>todas las categorias</option>
                <option value="comida">comida</option>
                <option value="tecnologia">tecnologia</option>
            </select>
        </div>
        <!--esta el para el perfil-->
        <div id="pefil">
            <!--foto de perfil-->
            <div id="foto-perfil">
                <img src="data:imagejpg;base64, <?php echo base64_encode($imagen) ?>" alt="">
            </div>
            <!--menu del perfil-->
            <div id="menu-del-perfil">
                <select name="" id="select-del-menu">
                    <option value="">Opciones</option>
                    <option value="">Productos favoritos</option>
                    <option value="Perfil">Perfil</option>
                    <option value="cerrarsesion">cerrar sesion</option>
                </select>
            </div>
        </div>
        <!--esta es para la canasta-->
        <div id="canasta">
            <button id="button-canasta"><img src="./img/canasta.png" alt=""></button>
        </div>
    </div>
</div>
<!--fin del nav-->
<!-------------------------------------------------->