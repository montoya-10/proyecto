<?php

session_start();
require('./database/db.php');
$usuario = $_SESSION['usuario'];
$id = $_SESSION['id'];
?>
<?php
$connexion = Getconnect();
if (isset($usuario) && isset($id)) {
    $consulta = "select * from usuarios  where idusuario='$id'";
    $resultado = $connexion->query($consulta);
    while ($rows = $resultado->fetch_assoc()) {
        $id001 = $id;
        $names = $rows['nombres'];
        $email = $rows['email'];
    }
} else {
    $id001 = 000;
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soporte GVC</title>
    <link rel="stylesheet" href="./css/soporte.css">
    <link rel="stylesheet" href="./cssresposive/soporter.css">
    <script src="./javascript/soporte.js"></script>
</head>

<body>
    <header>
        <!--inicio del nav-->
        <div id="nav">
            <!--logo-->
            <div class="columns primera">
                <div id="logo">
                    <h1>g.v.c</h1>
                </div>
            </div>
            <!--opcion cerrar-->
            <div class="columns segunda">
                <button id="btncerrar">cerrar</button>
            </div>
        </div>
        <!--fin del nav-->
        <!---------------------------------------------->
    </header>

    <main>
        <!--inicio del container-->
        <div id="container">
            <div class="rows titulorows">
                <h1>Sistema de envios pqrs</h1>
            </div>
            <!--formulario-->
            <!--Nombres de la persona-->
            <div class="rows">
                <label for="">Nombre:</label> <input type="text" name="nombres" id="names" placeholder="Escribe tu nombre aqui" value="<?php echo $names ?>" required>
            </div>
            <!--email-->
            <div class="rows">
                <label for="">email:</label> <input type="text" name="email" id="email" placeholder="Escribe tu email" value="<?php echo $email ?>" required>
            </div>
            <!--asunto-->
            <div class="rows">
                <label for="">asunto:</label> <input type="text" name="asunto" id="asunto" placeholder="Escribe el asunto" required>
            </div>
            <!--asunto-->
            <div class="rows textarea">
                <textarea name="descripcion" id="descripcion" rows="5" id="descripcion" placeholder="Descripción" required></textarea>
            </div>
            <!--terminos y condicones-->
            <div class="rows ">
                <textarea name="" id="terminos" rows="5" placeholder="Descripción">
                        jdskfjkjskldfjlksdjfkldsjlkfjsdlkjflkdsjflksdjflkjdslkfjlsdkjflkdsjflkjsdlkfjlsdfa-flip-horizontal
                        jdskfjkjskldfjlksdjfkldsjlkfjsdlkjflkdsjflksdjflkjdslkfjlsdkjflkdsjflkjsdlkfjlsdfa-flip-horizontal
                        jdskfjkjskldfjlksdjfkldsjlkfjsdlkjflkdsjflksdjflkjdslkfjlsdkjflkdsjflkjsdlkfjlsdfa-flip-horizontal
                        jdskfjkjskldfjlksdjfkldsjlkfjsdlkjflkdsjflksdjflkjdslkfjlsdkjflkdsjflkjsdlkfjlsdfa-flip-horizontal
                        jdskfjkjskldfjlksdjfkldsjlkfjsdlkjflkdsjflksdjflkjdslkfjlsdkjflkdsjflkjsdlkfjlsdfa-flip-horizontal
                        jdskfjkjskldfjlksdjfkldsjlkfjsdlkjflkdsjflksdjflkjdslkfjlsdkjflkdsjflkjsdlkfjlsdfa-flip-horizontal
                        jdskfjkjskldfjlksdjfkldsjlkfjsdlkjflkdsjflksdjflkjdslkfjlsdkjflkdsjflkjsdlkfjlsdfa-flip-horizontal
                        jdskfjkjskldfjlksdjfkldsjlkfjsdlkjflkdsjflksdjflkjdslkfjlsdkjflkdsjflkjsdlkfjlsdfa-flip-horizontal
                    </textarea>
            </div>
            <!--check box-->
            <div class="rows">
                <div id="check">
                    <div class="checks">
                        <label for="si">acepto:</label><input type="checkbox" id="si">
                    </div>
                    <div class="checks">
                        <label for="no">no acepto:</label><input type="checkbox" id="no">
                    </div>
                </div>
            </div>
            <!--boton-->
            <div class="rows">
                <input type="button" name="enviar" id="btnenviar" value="Acepta los terminos y condiciones" disabled>
            </div>
            <input type="hidden" id="id" value="<?php echo $id001; ?>">
        </div>
        <!--fin del container-->
        <!---------------------------------------------->
    </main>


    <footer>
        <!--por ultimo el footer-->
        <div id="footer">
            <div class="columns-footer"></div>
            <div class="columns-footer"></div>
            <div class="columns-footer"></div>
        </div>
        <!--fin del footer-->
        <!---------------------------------------------->

    </footer>
    <!--codigo php-->

</body>

</html>