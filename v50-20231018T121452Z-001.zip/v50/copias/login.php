<?php
error_reporting(0);
session_start();
require('./database/db.php');
?>
<?php

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loing</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="./res/loginr.css">
    <script src="./javascript/login.js"></script>
</head>

<body>
    <!--inicio del nav-->
    <div id="nav">
        <!--logo-->
        <div class="nav-columnas">
            <div id="nav-img"> <img src="./img/logo.png" alt="logo"> </div>
        </div>
        <!--menu-->
        <div class="nav-columnas segunda">
            <ul>
                <li><a class="a" href="">soporte</a></li>
                <li><a class="a" href="">contacto</a></li>
                <li><a class="a" href="">acerca de:</a></li>
                <li><button id="btnlogin">🏠inicio</button></li>
            </ul>
        </div>
    </div>
    <!--fin del nav-->
    <!------------------------------------------------------>
    <!--nav para novil-->
    <div id="nav-movil">
        <!--logo-->
        <div class="columnas-menu-movil">
            <div id="nav-img"> <img src="./img/logo.png" alt="logo"> </div>
        </div>
        <!--boton menu del movil-->
        <div class="columnas-menu-movil boton001">
            <div id="boton-menu-movil">
                <button type="button" id="btn-menu-movil">☰</button>
            </div>
        </div>
    </div>
    <!--fin del nav para celulares-->
    <!------------------------------------------------------>
    <!--menu del nav para movil-->
    <div id="menu-movil">
        <ul>
            <li><a class="a" href="">soporte</a></li>
            <li><a class="a" href="">contacto</a></li>
            <li><a class="a" href="">acerca de:</a></li>
            <li><button id="btnloginmovil">🏠inicio</button></li>
        </ul>
    </div>
    <!--fin dl menu del nav para movil-->
    <!------------------------------------------------------>


    <!--incio del container-->
    <div id="container">
        <h1 id="titulo">Ingresar</h1>
        <br>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <!---->
            <div class="row">
                <input type="text" name="usuario" id="" placeholder="Usuario" required>
            </div>
            <!---->
            <div class="row">
                <input type="password" name="password" id="password" placeholder="Contraseña" required><input id="ojito" type="button" value="👀">
            </div>
            <!--olvido contraseña-->
            <div class="ro">
                <div class="aee">
                    <a href="password" target="_blank">¿Olvidaste tu contraseña?</a>
                </div>
                <div class="aee">
                    <a href="registrarse">Registrarse</a>
                </div>


            </div>
            <div class="row">
                <input id="btnenviardatos" name="enviar" type="button" value="ingresar">
            </div>
        </form>
        <?php $mensaje = $_GET['mensaje'];
        echo "<h1>" . $mensaje . "</h1>";
        ?>
    </div>
    <!--script de php-->
    <?php
    if (isset($_POST['enviar'])) {
        $usuario = $_POST['usuario'];
        $password = $_POST['password'];
        $ingresar = new login;
        $ingresar->ingresarusuario($usuario, $password);
    }
    ?>
    <!--fin del container-->
    <!------------------------------------------------------>

</body>

</html>